import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  api = 'http://localhost:8080/';

  productId = null;

  productArray: [];

  addProduct(data): Observable<any> {
    console.log(data);
    return this.http.post<any>(`${this.api}addProduct`, data);
  }

  getProductList() {
    this.http.get<any>(`${this.api}getProductList`).subscribe(data => {
      console.log(data.productList);
      this.productArray = data.productList;
    }, err => {
      console.log(err);
    });
  }

  updateProduct(data) {
    return this.http.post<any>(`${this.api}updateProduct`, data);
  }

  deleteProduct(productId) {
    return this.http.delete<any>(`${this.api}deleteProduct?productId=${productId}`);
  }

}